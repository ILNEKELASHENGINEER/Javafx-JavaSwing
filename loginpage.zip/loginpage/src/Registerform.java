import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Registerform extends JDialog{
    private JTextField tfname;
    private JTextField tfemail;
    private JTextField tfmobile;
    private JTextField tfaddrs;
    private JPasswordField tfpasswrd;
    private JPasswordField tfcnfrmpass;
    private JButton btnCancel;
    private JButton btnRegister;
    private JPanel registerPanel;

    public Registerform(JFrame parent){
        super(parent);
        setTitle("Create a new account");
        setContentPane(registerPanel);
        setMinimumSize(new Dimension(450,474));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            dispose();
            }
        });
        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registernewuser();
            }
        });
        setVisible(true);
    }

    private void registernewuser() {
        String name =tfname.getText();
        String email = tfemail.getText();
        String phone = tfmobile.getText();
        String address = tfaddrs.getText();
        String password = String.valueOf(tfpasswrd.getPassword());
        String confirmpassword = String.valueOf(tfcnfrmpass.getPassword());
        if(name.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty() || password.isEmpty()){
            JOptionPane.showMessageDialog(this,
                    "Please Fill all the Fields",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(!password.equals(confirmpassword)){
            JOptionPane.showMessageDialog(this,
                    "Password Dont Match",
                    "Try again Dude :(",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        addUserToDatabase(name,email,phone,address,password);
    }

    public User user;
    private User addUserToDatabase(String name, String email, String phone, String address, String password) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost/MalNeha?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try{
            Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);

            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO users(name,email,phone,address,password)"+"VALUES (?,?,?,?,?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1,name);
            preparedStatement.setString(2,email);
            preparedStatement.setString(3,phone);
            preparedStatement.setString(4,address);
            preparedStatement.setString(5,password);

            //INSERTING INTO TABLE
            int addedrows = preparedStatement.executeUpdate();
            if(addedrows>0){
                user = new User();
                user.name = name;
                user.email = email;
                user.phone = phone;
                user.address = address;
                user.password= password;
            }
            stmt.close();
            conn.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return user;
    }

    public static void main(String []args){
        Registerform myform = new Registerform(null);
        User user = myform.user;
        if(user != null){
            System.out.println("Successful registration of: "+user.name);
        }
        else{
            System.out.println("Registration Cancelled");
        }
    }
}
